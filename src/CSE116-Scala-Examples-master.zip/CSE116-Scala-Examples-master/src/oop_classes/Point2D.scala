package oop_classes

class Point2D(var x: Double, var y: Double) {

}
