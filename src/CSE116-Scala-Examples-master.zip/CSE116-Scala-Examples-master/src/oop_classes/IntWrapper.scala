package oop_classes

class IntWrapper {

  var x:Int = 0

  def doubleX(): Unit = {
    this.x *= 2
  }

}
