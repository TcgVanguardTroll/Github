package oop_classes;

public class AccessModifiers{

    // NOTE: This is Java code

    private int x;

    public int getX(){
        return this.x;
    }

    public void setX(int x){
        this.x = x;
    }
}
