package memory

class ClassWithState(var state: Int) {

}
