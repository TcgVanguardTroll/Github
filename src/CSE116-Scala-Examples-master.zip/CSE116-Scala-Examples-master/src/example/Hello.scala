package example

object Hello {

  def main(args: Array[String]): Unit = {
    println("Hello Scala!")
  }

}
